# Este es un modulo con funciones que despiden


def adios():
    print("Hola te estoy despidiendo desde la funcion adios del modulo despedidas")


class despedido:
    def __init__(self):
        print("hola te estoy despidiendo desde el init de la clase despedido")

