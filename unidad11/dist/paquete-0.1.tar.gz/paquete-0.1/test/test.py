# from saludos import saludar

# saludar()

# from saludos import Saludo


# Saludo()

import sys

sys.path.insert(1, "..")
print(sys.path)

