from setuptools import setup

setup(
    name="paquete",
    version="0.1",
    description="este es un paquete de ejemplo",
    author="el arnold",
    author_email="elarnold@gmail.com",
    scripts=[],
    packages=["paquete", "paquete.adios", "paquete.hola"],
)

